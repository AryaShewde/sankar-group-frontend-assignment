import './Footer.css'

const currentYear = new Date().getFullYear()

const footerLinks = {
  product: [
    { label: 'Features', href: '#features' },
    { label: 'How it works', href: '#how-it-works' },
    { label: 'Pricing', href: '#pricing' },
    { label: 'Changelog', href: '#' },
  ],
  company: [
    { label: 'About', href: '#' },
    { label: 'Blog', href: '#' },
    { label: 'Careers', href: '#' },
    { label: 'Press', href: '#' },
  ],
  resources: [
    { label: 'Documentation', href: '#' },
    { label: 'Help Center', href: '#' },
    { label: 'Community', href: '#' },
    { label: 'API Reference', href: '#' },
  ],
  legal: [
    { label: 'Privacy', href: '#' },
    { label: 'Terms', href: '#' },
    { label: 'Security', href: '#' },
    { label: 'Cookies', href: '#' },
  ]
}

function handleLinkClick(e, href) {
  e.preventDefault()
  const target = document.querySelector(href)
  if (target) {
    target.scrollIntoView({ behavior: 'smooth' })
  }
}

function Footer() {
  return (
    <footer className="footer" role="contentinfo">
      <div className="footer-bg" aria-hidden="true">
        <div className="bg-glow footer-glow" aria-hidden="true"></div>
      </div>
      <div className="container">
        <div className="footer-grid">
          <div className="footer-brand">
            <a href="#" className="logo" aria-label="Proofdesk home">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <rect x="3" y="3" width="18" height="18" rx="4" stroke="currentColor" strokeWidth="2"/>
                <path d="M9 12l2 2 4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              proofdesk
            </a>
            <p className="footer-tagline">Client feedback, without the back-and-forth.</p>
            <p className="footer-desc">
              A simple, organized workspace for freelancers and creative teams to collect feedback, track revisions, and get approvals.
            </p>
            <div className="footer-social">
              <a href="#" className="social-link" aria-label="Twitter">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </a>
              <a href="#" className="social-link" aria-label="GitHub">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </a>
              <a href="#" className="social-link" aria-label="LinkedIn">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <rect x="2" y="9" width="4" height="12" rx="1" stroke="currentColor" strokeWidth="1.5"/>
                  <circle cx="4" cy="4" r="2" stroke="currentColor" strokeWidth="1.5"/>
                </svg>
              </a>
            </div>
          </div>

          <nav className="footer-nav" aria-label="Footer navigation">
            <div className="footer-nav-col">
              <h4 className="footer-nav-title">Product</h4>
              <ul className="footer-links">
                {footerLinks.product.map(link => (
                  <li key={link.label}>
                    <a href={link.href} onClick={e => handleLinkClick(e, link.href)}>{link.label}</a>
                  </li>
                ))}
              </ul>
            </div>
            <div className="footer-nav-col">
              <h4 className="footer-nav-title">Company</h4>
              <ul className="footer-links">
                {footerLinks.company.map(link => (
                  <li key={link.label}>
                    <a href={link.href} onClick={e => handleLinkClick(e, link.href)}>{link.label}</a>
                  </li>
                ))}
              </ul>
            </div>
            <div className="footer-nav-col">
              <h4 className="footer-nav-title">Resources</h4>
              <ul className="footer-links">
                {footerLinks.resources.map(link => (
                  <li key={link.label}>
                    <a href={link.href} onClick={e => handleLinkClick(e, link.href)}>{link.label}</a>
                  </li>
                ))}
              </ul>
            </div>
            <div className="footer-nav-col">
              <h4 className="footer-nav-title">Legal</h4>
              <ul className="footer-links">
                {footerLinks.legal.map(link => (
                  <li key={link.label}>
                    <a href={link.href} onClick={e => handleLinkClick(e, link.href)}>{link.label}</a>
                  </li>
                ))}
              </ul>
            </div>
          </nav>
        </div>

        <div className="footer-bottom">
          <div className="footer-bottom-inner">
            <p className="copyright">
              Built as a frontend assignment demo &mdash; not a real product.
            </p>
            <p className="copyright">
              &copy; {currentYear} Proofdesk. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer