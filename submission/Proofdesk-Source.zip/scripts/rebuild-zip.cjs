const AdmZip = require('adm-zip');
const fs = require('fs');
const path = require('path');

const projectRoot = 'C:/Users/aryas/OneDrive/Desktop/Job or Internship work/sankar-group-frontend-assignment';
const zipPath = path.join(projectRoot, 'submission/Proofdesk-Source.zip');

// Remove existing ZIP
if (fs.existsSync(zipPath)) {
  fs.unlinkSync(zipPath);
}

const zip = new AdmZip();

// Add directories
const dirsToAdd = ['src', 'public', 'scripts', 'screenshots'];
dirsToAdd.forEach(dir => {
  const fullPath = path.join(projectRoot, dir);
  if (fs.existsSync(fullPath)) {
    zip.addLocalFolder(fullPath, dir);
    console.log(`Added directory: ${dir}`);
  }
});

// Add root-level files
const filesToAdd = [
  'index.html',
  'package.json',
  'vite.config.js',
  'README.md',
  'DESIGN-NOTES.md',
  'postcss.config.js',
  '.gitignore'
];

filesToAdd.forEach(file => {
  const fullPath = path.join(projectRoot, file);
  if (fs.existsSync(fullPath)) {
    zip.addLocalFile(fullPath, '');
    console.log(`Added file: ${file}`);
  }
});

// Write ZIP
zip.writeZip(zipPath);
console.log(`\n✅ ZIP created successfully at: ${zipPath}`);

// Verify contents
const verifyZip = new AdmZip(zipPath);
const entries = verifyZip.getEntries();
console.log(`\n📦 Total entries in ZIP: ${entries.length}`);

// Check for key files
const requiredFiles = [
  'README.md',
  'DESIGN-NOTES.md',
  'package.json',
  'src/App.jsx',
  'src/index.css',
  'public/hero-poster.webp',
  'screenshots/desktop-full-page.png',
  'screenshots/desktop-hero.png',
  'screenshots/mobile-full-page.png'
];

let allPresent = true;
requiredFiles.forEach(reqFile => {
  const exists = entries.some(e => e.entryName === reqFile);
  if (!exists) {
    console.log(`❌ Missing: ${reqFile}`);
    allPresent = false;
  }
});

if (allPresent) {
  console.log('\n✅ All required files present in ZIP!');
}

// Show size info
const stats = fs.statSync(zipPath);
console.log(`\n💾 ZIP file size: ${(stats.size / 1024 / 1024).toFixed(2)} MB`);
