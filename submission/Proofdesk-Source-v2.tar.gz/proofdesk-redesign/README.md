# Proofdesk — Client Feedback Without the Back-and-Forth

A responsive SaaS landing page built as a frontend development assignment for Sankar Group.

## Project Overview

Proofdesk is a fictional client review and approval platform designed for freelancers, creative agencies, and small teams. This landing page demonstrates the product's value proposition through clean, editorial design with functional interactions.

**Target audience:** Freelancers, design agencies, web development teams, and small creative groups who struggle with scattered client feedback across email threads and chat messages.

## Features

- **Navigation** — Sticky header with smooth-scroll links and mobile hamburger menu
- **Hero Section** — Compelling headline with interactive dashboard preview built entirely in CSS/HTML
- **Features** — Three core features with inline SVG icons
- **How It Works** — Three-step workflow visualization (Upload → Review → Approve)
- **Pricing** — Two-tier pricing cards (Free & Pro) with feature comparison
- **Contact Form** — Frontend-validated form with success state
- **Footer** — Clean footer with navigation links and dynamic copyright year

## Technologies

- **React 19** — UI framework
- **Vite 8** — Build tool and dev server
- **JavaScript (JSX)** — Component language
- **CSS3** — Styling with custom properties (design tokens)
- **Google Fonts** — Inter typeface
- **Inline SVG** — Icons (no external icon library)

## Getting Started

### Prerequisites
- Node.js 18+ 
- npm 9+

### Installation

```bash
npm install
```

### Development

```bash
npm run dev
```

Opens the development server at http://localhost:5173

### Production Build

```bash
npm run build
```

### Preview Production Build

```bash
npm run preview
```

## Project Structure

```
sankar-group-frontend-assignment/
├── src/
│   ├── components/
│   │   ├── Navbar.jsx       # Responsive navigation with mobile menu
│   │   ├── Navbar.css
│   │   ├── Hero.jsx         # Hero section with dashboard preview
│   │   ├── Hero.css
│   │   ├── Features.jsx     # Feature cards with SVG icons
│   │   ├── Features.css
│   │   ├── HowItWorks.jsx   # Three-step workflow section
│   │   ├── HowItWorks.css
│   │   ├── Pricing.jsx      # Two-tier pricing cards
│   │   ├── Pricing.css
│   │   ├── Contact.jsx      # Contact section wrapper
│   │   ├── Contact.css
│   │   ├── ContactForm.jsx  # Form with validation logic
│   │   ├── ContactForm.css
│   │   ├── Footer.jsx       # Footer with nav links
│   │   └── Footer.css
│   ├── App.jsx              # Root component
│   ├── main.jsx             # React entry point
│   └── index.css            # Global styles and design tokens
├── public/
│   └── favicon.svg          # Site favicon
├── scripts/
│   └── take-screenshots.js  # Playwright screenshot script
├── index.html               # HTML entry point
├── package.json
├── vite.config.js
└── README.md
```

## Responsive Design

The layout adapts across four breakpoints:

| Viewport | Width | Behavior |
|----------|-------|----------|
| Desktop | 1440px | Full two-column hero, 3-col features grid, horizontal steps |
| Laptop | 1024px | Hero stacks vertically, features remain 2-col |
| Tablet | 768px | Mobile nav toggle appears, single-column layouts begin |
| Mobile | 375px | All sections stack, sidebar collapses, full-width CTAs |

Key techniques:
- CSS Grid with `repeat(3, 1fr)` and `repeat(2, 1fr)` for responsive grids
- `clamp()` for fluid typography scaling
- Media queries at 900px, 768px, and 600px breakpoints
- Touch-friendly tap targets on mobile (min 44px)

## Form Behavior

The contact form performs **client-side validation only**:

- **Name** — Required, trimmed, non-empty check
- **Email** — Required, regex format validation (`user@domain.com`)
- **Company** — Optional field
- **Message** — Required, trimmed, minimum length check

On valid submission:
- Prevents default browser form submission
- Displays a success confirmation message
- Clarifies this is a frontend demo with no backend
- Offers "Send another message" to reset the form

No data is sent to any server. The form uses React state management (`useState`) for values and error handling.

## Design Decisions

**Visual Direction:** Editorial minimalism inspired by premium SaaS products like Linear and Raycast.

**Color Palette:**
- Warm off-white background (#F5F3EC) for an approachable, professional feel
- Deep forest green text (#192B24) instead of pure black for reduced eye strain
- Fresh lime accent (#D6F28A) for CTAs and highlights — distinctive without being generic
- Subtle borders and shadows for depth without clutter

**Typography:** Inter font family for excellent readability across screen sizes.

**Dashboard Preview:** Built entirely with HTML/CSS divs — no images, no external assets. Contains realistic but fictional content (project names, comment threads, status badges).

**Accessibility:** Semantic HTML landmarks (`<nav>`, `<main>`, `<footer>`), ARIA labels, visible focus states, keyboard navigation support, and `prefers-reduced-motion` respect.

## Deployment

### Vercel (Recommended)

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel
```

Or connect your GitHub repository to Vercel for automatic deployments.

### Netlify

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Deploy
netlify deploy --prod --dir=dist
```

Or drag-and-drop the `dist/` folder at app.netlify.com.

Both platforms provide free hosting with custom domain support.

## Screenshots

Three screenshots are included in the `screenshots/` directory:

- `desktop-full-page.png` — 1440×900 full-page scroll capture
- `mobile-full-page.png` — 375×812 mobile view
- `desktop-hero.png` — 1440×900 hero section close-up

Generated using Playwright with full-page capture enabled.

## Live Demo

Visit the deployed site at: [proofdesk-demo.vercel.app](https://proofdesk-demo.vercel.app)

## License

Built as a frontend development assignment for Sankar Group. Educational use only.
