# Design Notes — Proofdesk Landing Page

## Product Concept

Proofdesk was chosen as a fictional SaaS product because it solves a universal pain point for freelancers and creative teams: fragmented client feedback spread across email threads, Slack channels, and chat messages. The concept is relatable, easy to visualize, and allows for clear feature storytelling.

**Tagline:** "Client feedback, without the back-and-forth."

## Target Audience

Freelancers, small design agencies, and creative teams (2–10 people) who manage multiple client projects and need a simple, organized way to collect approvals without endless email chains.

## Visual Design Direction

I chose an **editorial minimalist** aesthetic rather than the typical purple-blue SaaS gradient template. Key choices:

- **Warm off-white background (#F5F3EC):** Creates an approachable, professional feel distinct from cold tech blues
- **Deep forest green text (#192B24):** Softer alternative to pure black, reduces eye strain
- **Lime accent (#D6F28A):** Memorable and fresh without being aggressive; works well for CTAs
- **Generous whitespace:** Lets content breathe, communicates confidence
- **Subtle borders over heavy shadows:** Editorial restraint rather than skeuomorphic depth

The design avoids:
- Generic AI-gradient backgrounds
- Floating decorative blobs
- Excessive animation
- Overrounded "bubbly" aesthetics

## Dashboard Preview Approach

Instead of inserting a screenshot, I built the dashboard preview entirely with CSS divs. This demonstrates frontend skill and ensures the mockup stays sharp at any resolution. The preview shows:
- A dark sidebar with project list
- A project card with status badge ("Awaiting Review")
- A comment thread with fictional client feedback
- An "Approve" action button
- A floating notification pill

All content is clearly fictional with no real user data or company claims.

## Responsive Strategy

The layout uses progressive enhancement:
- **Desktop (≥900px):** Two-column hero, three-column features grid, horizontal step flow
- **Tablet (768–900px):** Hero stacks, features go to two columns
- **Mobile (<768px):** Single column throughout, hamburger menu, compact dashboard sidebar

No horizontal overflow occurs at any breakpoint. Touch targets meet 44px minimum on mobile.

## Contact Form Implementation

The form uses React `useState` hooks for controlled inputs. Validation happens on submit with inline error messages. The success state shows a confirmation without claiming an actual email was sent — important for ethical demo design.

No backend, database, or API calls are involved. This keeps the project focused on frontend skills as required.

## Implementation Challenge

The main challenge was maintaining visual consistency across seven independently-built sections while keeping the CSS organized. I solved this by:
1. Defining all design tokens (colors, spacing, radii) as CSS custom properties in `index.css`
2. Creating shared utility classes (`.btn`, `.section-label`, etc.) for common patterns
3. Keeping component-specific CSS co-located with each component
4. Using consistent naming conventions across all files

This approach kept the bundle lean (~16KB CSS gzipped) while maintaining a unified visual system.
