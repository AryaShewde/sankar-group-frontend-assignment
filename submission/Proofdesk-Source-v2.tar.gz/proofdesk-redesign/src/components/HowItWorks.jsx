import { useState, useEffect, useRef } from 'react'
import './HowItWorks.css'

const steps = [
  {
    number: '01',
    title: 'Upload',
    description: 'Share your deliverable with your client by uploading it to Proofdesk.',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <polyline points="17 8 12 3 7 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <line x1="12" y1="3" x2="12" y2="15" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      </svg>
    ),
  },
  {
    number: '02',
    title: 'Review',
    description: 'Collect feedback and track requested changes as they come in.',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <circle cx="11" cy="11" r="8" stroke="currentColor" strokeWidth="1.5"/>
        <path d="m21 21-4.35-4.35" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M11 8v6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M8 11h6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      </svg>
    ),
  },
  {
    number: '03',
    title: 'Approve',
    description: 'Get a clear, recorded approval when the work is done.',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        <polyline points="22 4 12 14.01 9 11.01" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
  },
]

function StepCard({ step, index, total }) {
  const ref = useRef(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setTimeout(() => setIsVisible(true), index * 150)
        observer.unobserve(entry.target)
      }
    }, { threshold: 0.2 })

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [index])

  return (
    <div
      ref={ref}
      className={`step ${isVisible ? 'visible' : ''}`}
      style={{ transitionDelay: `${index * 150}ms` }}
    >
      <div className="step-number-wrap">
        <span className="step-number">{step.number}</span>
        <div className="step-icon">{step.icon}</div>
      </div>
      <h3 className="step-title">{step.title}</h3>
      <p className="step-desc">{step.description}</p>
      {index < total - 1 && (
        <svg className="step-arrow" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M5 12h14M12 5l7 7-7 7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      )}
    </div>
  )
}

function HowItWorks() {
  const ref = useRef(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsVisible(true)
        observer.unobserve(entry.target)
      }
    }, { threshold: 0.15 })

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section id="how-it-works" className="how-it-works" aria-label="How it works">
      <div className="how-it-works-bg" aria-hidden="true"></div>
      <div className="page-container">
        <div className={`how-it-works-header ${isVisible ? 'visible' : ''}`}>
          <p className="section-label">How it works</p>
          <h2 className="section-title">Three steps from upload to approval</h2>
        </div>

        <div className="steps-grid">
          {steps.map((step, index) => (
            <StepCard key={step.number} step={step} index={index} total={steps.length} />
          ))}
        </div>
      </div>
    </section>
  )
}

export default HowItWorks
