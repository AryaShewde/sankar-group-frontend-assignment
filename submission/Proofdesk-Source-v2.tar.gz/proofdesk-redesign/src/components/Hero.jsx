import { useEffect, useState } from 'react'
import './Hero.css'

function Hero() {
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    setLoaded(true)
  }, [])

  return (
    <section className="hero" aria-label="Introduction">
      {/* Ambient background effects */}
      <div className="hero-bg">
        <div className="bg-glow glow-1"></div>
        <div className="bg-glow glow-2"></div>
        <div className="bg-grid"></div>
      </div>

      <div className="hero-inner page-container">
        {/* Left: Content */}
        <div className={`hero-content ${loaded ? 'visible' : ''}`}>
          <p className="eyebrow">For freelancers & creative teams</p>
          <h1>Client feedback,<br/>without the<br/><span className="accent-text">back-and-forth.</span></h1>
          <p className="hero-desc">
            Proofdesk gives you a clean workspace to collect comments, track revisions, and get approvals — instead of hunting through email threads and chat messages.
          </p>
          <div className="cta-group">
            <a href="#contact" className="btn btn-primary">
              Start your workspace
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M5 12h14M12 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </a>
            <a href="#how-it-works" className="btn btn-secondary">See how it works</a>
          </div>
          <div className="hero-trust">
            <div className="trust-item">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <polyline points="20 6 9 17 4 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span>No credit card required</span>
            </div>
            <div className="trust-item">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <polyline points="20 6 9 17 4 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span>14-day free trial</span>
            </div>
          </div>
        </div>

        {/* Right: Dashboard Preview */}
        <div className={`hero-visual ${loaded ? 'visible' : ''}`}>
          <div className="dashboard-window">
            {/* Window chrome */}
            <div className="window-bar">
              <div className="window-dots">
                <span className="dot dot-red" aria-hidden="true"></span>
                <span className="dot dot-yellow" aria-hidden="true"></span>
                <span className="dot dot-green" aria-hidden="true"></span>
              </div>
              <div className="window-url">
                <span className="url-icon" aria-hidden="true">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none">
                    <rect x="3" y="11" width="18" height="11" rx="2" stroke="currentColor" strokeWidth="2"/>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                  </svg>
                </span>
                app.proofdesk.io/workspace
              </div>
            </div>

            {/* Dashboard body */}
            <div className="dashboard-body">
              {/* Sidebar */}
              <aside className="sidebar">
                <div className="sidebar-header">
                  <div className="sidebar-logo">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                      <rect x="3" y="3" width="18" height="18" rx="4" stroke="currentColor" strokeWidth="2"/>
                      <path d="M9 13l2 2 4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                    proofdesk
                  </div>
                </div>
                <nav className="sidebar-nav">
                  <ul>
                    <li><span className="sidebar-item active"><svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" stroke="currentColor" strokeWidth="1.5"/><polyline points="9 22 9 12 15 12 15 22" stroke="currentColor" strokeWidth="1.5"/></svg>Dashboard</span></li>
                    <li><span className="sidebar-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke="currentColor" strokeWidth="1.5"/><circle cx="9" cy="7" r="4" stroke="currentColor" strokeWidth="1.5"/></svg>Projects</span></li>
                    <li><span className="sidebar-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" stroke="currentColor" strokeWidth="1.5"/></svg>Messages</span></li>
                    <li><span className="sidebar-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.5"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" stroke="currentColor" strokeWidth="1.5"/></svg>Settings</span></li>
                  </ul>
                </nav>
              </aside>

              {/* Main area */}
              <main className="main-area">
                {/* Top bar */}
                <div className="topbar">
                  <div className="topbar-search">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                      <circle cx="11" cy="11" r="8" stroke="currentColor" strokeWidth="2"/>
                      <path d="m21 21-4.35-4.35" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    </svg>
                    <span>Search projects...</span>
                  </div>
                  <div className="topbar-actions">
                    <button className="icon-btn" aria-label="Notifications">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                        <path d="M13.73 21a2 2 0 0 1-3.46 0" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                      </svg>
                    </button>
                    <div className="avatar" aria-hidden="true"></div>
                  </div>
                </div>

                {/* Project card */}
                <div className="project-card">
                  <div className="card-header">
                    <div className="card-thumb">
                      <div className="thumb-gradient"></div>
                    </div>
                    <div className="card-info">
                      <h3 className="card-title">Website Redesign — Homepage</h3>
                      <span className="status-badge status-pending">Awaiting Review</span>
                    </div>
                  </div>
                  <div className="card-meta">
                    <span className="meta-item">
                      <span className="meta-dot" aria-hidden="true"></span>
                      3 revisions
                    </span>
                    <span className="meta-item">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                        <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>
                      </svg>
                      5 comments
                    </span>
                    <span className="meta-item">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                        <circle cx="12" cy="12" r="10"/>
                        <polyline points="12 6 12 12 16 14"/>
                      </svg>
                      Updated 2h ago
                    </span>
                  </div>
                </div>

                {/* Comment thread */}
                <div className="comment-thread">
                  <div className="thread-header">
                    <span>Recent Comments</span>
                    <span className="badge-count">5</span>
                  </div>
                  <div className="comment-list">
                    <div className="comment-row">
                      <div className="comment-avatar avatar-a" aria-hidden="true"></div>
                      <div className="comment-bubble">
                        <div className="comment-author">Sarah M.</div>
                        <div className="comment-text">Can we adjust the spacing on the hero section?</div>
                      </div>
                    </div>
                    <div className="comment-row">
                      <div className="comment-avatar avatar-b" aria-hidden="true"></div>
                      <div className="comment-bubble">
                        <div className="comment-author">Alex K.</div>
                        <div className="comment-text">Looks great overall — just minor tweak needed.</div>
                      </div>
                    </div>
                  </div>
                </div>

                <button className="approve-btn" type="button">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <polyline points="20 6 9 17 4 12" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                  Approve & Close
                </button>
              </main>
            </div>
          </div>

          {/* Floating glass notification cards */}
          <div className="float-card float-approval">
            <div className="float-card-icon success" aria-hidden="true">✓</div>
            <div className="float-card-content">
              <div className="float-card-title">Project Approved</div>
              <div className="float-card-sub">Website Redesign • Just now</div>
            </div>
          </div>

          <div className="float-card float-comment">
            <div className="float-card-icon comment" aria-hidden="true">💬</div>
            <div className="float-card-content">
              <div className="float-card-title">New Feedback</div>
              <div className="float-card-sub">Sarah M. left 3 comments</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Hero
