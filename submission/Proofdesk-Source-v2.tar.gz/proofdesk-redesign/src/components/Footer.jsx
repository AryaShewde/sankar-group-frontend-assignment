import './Footer.css'

const currentYear = new Date().getFullYear()

const footerLinks = [
  { label: 'Features', href: '#features' },
  { label: 'How it works', href: '#how-it-works' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Contact', href: '#contact' },
]

function handleLinkClick(e, href) {
  e.preventDefault()
  const target = document.querySelector(href)
  if (target) {
    target.scrollIntoView({ behavior: 'smooth' })
  }
}

function Footer() {
  return (
    <footer className="footer" role="contentinfo">
      <div className="page-container">
        <div className="footer-inner">
          <div className="footer-brand">
            <a href="#" className="logo" aria-label="Proofdesk home">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <rect x="3" y="3" width="18" height="18" rx="4" stroke="currentColor" strokeWidth="2"/>
                <path d="M9 12l2 2 4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              proofdesk
            </a>
            <p className="footer-tagline">Client feedback, without the back-and-forth.</p>
            <p className="footer-desc">
              A simple, organized workspace for freelancers and creative teams to collect feedback, track revisions, and get approvals.
            </p>
          </div>

          <nav aria-label="Footer navigation">
            <p className="footer-nav-title">Product</p>
            <ul className="footer-links">
              {footerLinks.map(link => (
                <li key={link.label}>
                  <a href={link.href} onClick={e => handleLinkClick(e, link.href)}>{link.label}</a>
                </li>
              ))}
            </ul>
          </nav>

          <div className="footer-legal">
            <p className="footer-tagline-footer">Built as a frontend assignment demo — not a real product.</p>
          </div>
        </div>

        <div className="footer-bottom">
          <p>&copy; {currentYear} Proofdesk. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
